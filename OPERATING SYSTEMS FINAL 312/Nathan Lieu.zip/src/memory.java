import java.util.ArrayList;

public class memory
{
    private final int memoryArray [] = new int[ 4096];
    private int base =0;
    private int limit = 0;
    private int total_memory_left=4096;


    public void load_all_memory(ArrayList<Process> x )
    {
        for( int i=0; i< x.size(); i++) // next process in ready queque
        {
            if(x.get(i).getProcessState()==ProcessState.Ready)
            {
                total_memory_left=total_memory_left-x.get(i).getMemory();
                x.get(i).setBaseRegister(base);// base
                limit= base+x.get(i).getMemory(); // base + memory size = limit
                x.get(i).setLimitRegister(limit);// limit regsiter
                for(int j=base; j<limit; j++)
                {
                    memoryArray[j]=x.get(i).getPid();// populates with each block will have process number
                }
                base=limit; // sets new base for next process

            }
        }
    }

}
