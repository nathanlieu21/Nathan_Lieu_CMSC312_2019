import java.io.*;
import java.util.*;
public class FileReader {

    public static void main(String[] args) throws Exception {
        Scanner in = new Scanner(System.in);
        int fileNum = 0;
        String filename; //stores file name
        int runtime = 0; //cpu timw total
        int memory = 0;//memory allocated
        int counter = 0;// pid
        String name = "";//search directory
        int filecounter = 0;// amount of files increment
        String x = "";//amount of files
        ArrayList<Process> allfiles = new ArrayList<Process>(); //arraylist of processes
        System.out.println("How many files do you have ?");//user prompt
        x = in.nextLine(); // number of files
        String direcotry=""; // directory location
        System.out.println("Enter Directory example given:" + "C:\\Users\\thebe\\git\\Nathan_Lieu_CMSC312_2019\\.git\\cmsc312 Operating Systems final\\");
        direcotry=in.nextLine();//takes in directory location
        while (filecounter < Integer.parseInt(x)) // creates x number of processes
        {
            System.out.println("Enter file name");
            filename = in.nextLine();// enter file name
            filecounter++;// increment counter
            /****************************************
             * Must change file location to your personalized directory
             */

            File file = new File(direcotry + filename); //file location in directory
            Scanner s = new Scanner(file);
            ArrayList<String> list = new ArrayList<String>(); // arraylist of strings to store each process instruction
            while (s.hasNext()) {// takes in all file values
                list.add(s.next());// stores each value into list
            }
            for (int i = 0; i < list.size(); i++) {
                if(list.get(i).equals("OUT")) // extra * added to deal with substring issues does not affect instructions
                {
                    list.add(i+1, "*");

                }
                if (list.get(i).equals("Name:")) { //find name of file must two words

                    name = list.get(i + 1) + " " + list.get(i+2);
                }
                if (list.get(i).equals("runtime:")) { // find total runtime
                    runtime = Integer.parseInt(list.get(i + 1));
                }
                if (list.get(i).equals("Memory:")) { //find total memory
                    memory = Integer.parseInt(list.get(i + 1));
                }
            }
            counter++;//pid starts from 1 and goes up
            Process p = new Process(name, counter, runtime, memory, ProcessState.New, list); //initalize each process
            allfiles.add(p);// add each process to arraylist of processes
            s.close();//close file reading

        }
        Scheduler schedulerQ = new Scheduler(); // initializes object
        schedulerQ.execute(allfiles); //runs processes instructions and memory










    }
}
