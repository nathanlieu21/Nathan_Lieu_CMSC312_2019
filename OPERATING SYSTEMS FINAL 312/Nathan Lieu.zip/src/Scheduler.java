import java.util.*;
import java.util.concurrent.TimeUnit;

public class Scheduler {
    // three queues always required in scheduler
    private ArrayList<Process> readyQueue = new ArrayList<Process>(); // store all processes to start
    private ArrayList<Process> executeQueue = new ArrayList<Process>(); //execution cpu
    private ArrayList<Process> waitQueue = new ArrayList<Process>();// stores all processes on interrupts and I/O
    private ArrayList<Integer> iocontrol = new ArrayList<Integer>();// holds all I/O call cycles
    private ArrayList<Integer> iohelper = new ArrayList<>();
    private final int memoryArray [] = new int[4096]; //main memory
    private int base =0;//base
    private int limit = 0;//limit
    private int total_memory_left=4096;// total memory
    private int counter=0; // runs until all processes done
    private int iocylce=0;// current I/O cycle
    private String processor; // read through each process instruction
    private int yieldcylces=0;
    private int switch1 =0;


    /* main component for shortest job first scheduler. It will sort based off shortest runtime after every iteration/change to readyQueue*/
    public void sort(ArrayList<Process> x) //sorting for all process based off runtime
    {
        Collections.sort(x, new Comparator<Process>()
        {
            @Override
            public int compare(Process a, Process b)
            {
                return Integer.compare(a.getTotalTime(), b.getTotalTime()); //sort arraylist in dascending order memory
            }
        });


    }
    /* initialized all processes to ready and loads them to memory*/
    public void readyAll(ArrayList<Process> x)// reads all processes in to ready queue and puts in memory
    {
        for( int i=0; i<x.size(); i++)
        {
            x.get(i).setProcessState(ProcessState.Ready); // all processes from new to ready
            readyQueue.add(x.get(i));// add readyQueue
            if(x.get(i).getProcessState()==ProcessState.Ready)// if ready load into memory
            {
                total_memory_left=total_memory_left-x.get(i).getMemory(); // total main memory remaining
                x.get(i).setBaseRegister(base);// base
                limit= base+x.get(i).getMemory(); // base + memory size = limit
                x.get(i).setLimitRegister(limit);// limit regsiter
                for(int j=base; j<limit; j++)
                {
                    memoryArray[j]=x.get(i).getPid();// populates with each block will have process number
                }
                base=limit; // sets new base for next process

            }
        }
    }


     public void Memoryprint(ArrayList<Process> x ) throws InterruptedException { //display memory
        System.out.println("Total memory left " + total_memory_left);
         for (int i = 0; i < x.size(); i++)
         {
             System.out.println( x.get(i).getName() + " has a base Register of : " + x.get(i).getBaseRegister() + " and a limit Register is " + x.get(i).getLimitRegister());
             TimeUnit.SECONDS.sleep( 2); //default to 2 seconds for out
         }
     }

    public void execute(ArrayList<Process >x) throws InterruptedException// executes runt im
    {
        sort(x);// sort everything based on total runtime
        readyAll(x);// puts all in memory
        Memoryprint(x); // show memory locations
        int end =readyQueue.size();// size of elements in ready queue end point
            while(counter!=end)// once all processes all done
            {
                sort(readyQueue);//shortest job first
                /* extra code ideas
                //System.out.println("The ready queue"+readyQueue.size());
                //System.out.println("The wait queue"+waitQueue.size());
                if (!waitQueue.isEmpty() & executeQueue.size()==0){ // can't load readQueue then load from waitQueue and critical section
                   System.out.println("Picked Wait to Ready ");
                    waitQueue.get(0).setProcessState(ProcessState.Ready);//change state
                    readyQueue.add(waitQueue.get(0));// add execute queue
                    waitQueue.remove(0); //remove wait queue
                }*/
                if(!readyQueue.isEmpty() & executeQueue.size()==0) // load process into from critical section
                {
                  //  System.out.println("Picked Ready");
                    readyQueue.get(0).setProcessState(ProcessState.Run); // change state
                    executeQueue.add(readyQueue.get(0)); //add execute queue
                    readyQueue.remove(0); // removes from ready queue
                }
              else if (!waitQueue.isEmpty() & executeQueue.size()==0){ // can't load readQueue then load from waitQueue and critical section
                   //System.out.println("Picked Wait");
                    waitQueue.get(0).setProcessState(ProcessState.Run);//change state
                    executeQueue.add(waitQueue.get(0));// add execute queue
                    waitQueue.remove(0); //remove wait queue
                }
            for(int i=0; i<executeQueue.get(0).getListInfo().size(); i++) //loop through process instructions
            {
                 processor = executeQueue.get(0).getindex(i); // file index
               if (processor.equals("I/O")) // wait call
                {
                    //System.out.println("I/O Test");
                    iocontrol.add(Integer.parseInt(executeQueue.get(0).getindex(i + 1)));//finds allocated I/O time add to I/O list
                    iohelper.add(Integer.parseInt(executeQueue.get(0).getindex(i + 1))); // deals with io calls
                    iocylce=iohelper.get(0); //store current I/O cycle and show user
                    executeQueue.get(0).setProcessState(ProcessState.Wait);// I/O changes
                    executeQueue.get(0).removeindex(i);// remove index
                    executeQueue.get(0).setListInfo(i);// save changes to file if process switches
                    i = i - 1; // fix index position
                    waitQueue.add(executeQueue.get(0)); // add wait queue
                    /* extra debugger info
                    for(int p=0; p<iohelper.size(); p++)
                    {
                        System.out.println(iohelper.get(p)+ " " + p);

                    }*/

                    if(iohelper.get(0)!=iocontrol.get(0)) { // compares original io cycle to deals with leftover cylces ex: 20-10 still runs 20
                        System.out.println("The I/O call switching time left processes putting " + executeQueue.get(0).getName() + " onto waitQueue for " + iohelper.get(1) + " cycles"); // shows current process and I/O cycle running
                        switch1=1;
                    }
                    else if(iohelper.get(0)==iocontrol.get(0) & iohelper.size()==2) //special condition
                    {
                        System.out.println("The I/O call switching processes putting " + executeQueue.get(0).getName() + " onto waitQueue for " + iohelper.get(1) + " cycles");
                        switch1=2;
                    }
                    else //iocylce equals original cycle
                    {
                        System.out.println("The I/O call switching processes putting " + executeQueue.get(0).getName() + " onto waitQueue for " + iohelper.get(0) + " cycles");
                        switch1=2;
                    }
                    executeQueue.remove(0); //removes from execute

                    if(readyQueue.isEmpty())// case when all process on waitQueue
                    {
                        if(switch1==1) { //gets cycle being run when all processes on waitQUEUE
                            System.out.println("No Processes available " + iohelper.get(0) + " cycles"); //runs cycles nothing on wiatQueue
                            TimeUnit.SECONDS.sleep( (long) (.04 *  iohelper.get(0)));
                        }
                        else if(switch1==2)
                        {
                            System.out.println("No Processes available " + iohelper.get(0) + " cycles"); //runs cycles nothing on wiatQueue
                            TimeUnit.SECONDS.sleep( (long) (.04 *  iohelper.get(0)));
                        }
                       iocontrol.remove(0); //reset both
                        iohelper.remove(0);
                        waitQueue.get(0).setProcessState(ProcessState.Ready); //changes first waitQeuue to readyQueue
                        readyQueue.add(waitQueue.get(0)); //adds to readyQueue
                        waitQueue.remove(0); // removes waitQueue
                        sort(readyQueue); //sort
                        break;// go back initial while loop find next process

                    }
                    else if (!waitQueue.isEmpty())//process in Ready goes back to while loop and picks off ready
                    {
                        break; // go back initial while loop find next process
                    }

                }
                else if (processor.equals("CALCULATE") & !iocontrol.isEmpty()) { //if I/O is being run subtracts cpu time form current I/O
                    //System.out.println("CACULATE TEST AND IO");
                    System.out.println(( executeQueue.get(0).getName() + "The total runtime is " + executeQueue.get(0).getTotalTime() + " current instruction of calculate is " + executeQueue.get(0).getindex(i + 1)));
                    executeQueue.get(0).setTotalTime(executeQueue.get(0).getTotalTime() - Integer.parseInt(executeQueue.get(0).getindex(i + 1))); //gets value - time
                    iocontrol.set(0,iocontrol.get(0) -Integer.parseInt(executeQueue.get(0).getindex(i + 1))); // minus i/o changes
                    System.out.println("The I/O Call of " + iohelper.get(0) + " cycles is running");
                   TimeUnit.SECONDS.sleep( (long) (.04 *  Integer.parseInt(executeQueue.get(0).getindex(i + 1))));
                    executeQueue.get(0).removeindex(i); //reset both
                    executeQueue.get(0).setListInfo(i);
                    i = i - 1;
                    /* extra code idea
                    if(waitQueue.isEmpty())
                    {
                        iocontrol.remove(0);//remove io call
                        iohelper.remove(0);
                        break;
                    }*/
                    if(iocontrol.get(0)<=0 & !iocontrol.isEmpty())//I/O calls can stack up
                    {
                        //System.out.println("Reached");
                        iocontrol.remove(0);//remove io call
                        iohelper.remove(0);
                        waitQueue.get(0).setProcessState(ProcessState.Ready);// remove process associated with i/o call
                        readyQueue.add(waitQueue.get(0));// add readyqueue
                        sort(readyQueue);// order to smallest runtime
                        waitQueue.remove(0);
                        executeQueue.get(0).setProcessState(ProcessState.Ready);
                        readyQueue.add(executeQueue.get(0));
                        executeQueue.remove(0);
                        break;

                    }
                    else if(iocontrol.get(0)<=0 & iocontrol.size()==1) // last i/o call on list
                    {
                        //System.out.println("Reach");
                        iocontrol.remove(0);//remove io call
                        iohelper.remove(0);
                        waitQueue.get(0).setProcessState(ProcessState.Ready);// remove process associated with i/o call
                        readyQueue.add(waitQueue.get(0));// add readyqueue
                        sort(readyQueue);// order to smallest runtime
                        waitQueue.remove(0);
                        executeQueue.get(0).setProcessState(ProcessState.Ready);
                        readyQueue.add(executeQueue.get(0));
                        executeQueue.remove(0);
                        break;

                    }

                }
                 else if (processor.equals("CALCULATE")) { //regular if no io calls
                    //System.out.println("CACULATE Test");
                    System.out.println(( executeQueue.get(0).getName() + " The total runtime is " + executeQueue.get(0).getTotalTime() + " current instruction of calculate is " + executeQueue.get(0).getindex(i + 1)));
                    executeQueue.get(0).setTotalTime(executeQueue.get(0).getTotalTime() - Integer.parseInt(executeQueue.get(0).getindex(i + 1))); //gets value - time
                    TimeUnit.SECONDS.sleep( (long) (.04 *  Integer.parseInt(executeQueue.get(0).getindex(i + 1))));
                    executeQueue.get(0).removeindex(i);
                    executeQueue.get(0).setListInfo(i);
                    i = i - 1;//

                }
                else if(processor.equals("YIELD")) //yield call
                {
                    yieldcylces=Integer.parseInt(executeQueue.get(0).getindex(i + 1)); //gets cycles
                    executeQueue.get(0).setProcessState(ProcessState.Wait); //changes state to wait
                    waitQueue.add(0,executeQueue.get(0)); //add waitQueue
                    executeQueue.get(0).removeindex(i);// remove command from list
                    executeQueue.get(0).setListInfo(i);//remove command stored list
                    executeQueue.remove(0); //remove executeQueue
                    System.out.println("The current process " + waitQueue.get(0).getName() + " is put on yielded running " + yieldcylces + " cycles"); //shows which process is being yielded as process moved to wait
                    TimeUnit.SECONDS.sleep( (long) (.04 *  yieldcylces)); // pausefor x amount of cycles
                    waitQueue.get(0).setProcessState(ProcessState.Ready); //after yield finish change state to ready
                    readyQueue.add(0,waitQueue.get(0));// add to readyQueue
                    waitQueue.remove(0);//remove from waitQueue
                    i=i-1;// fix index location
                    break;//will select same Queue again

                }
                else if (processor.equals("OUT")) { //out call
                    System.out.println(executeQueue.get(0).printPCB());//print current process blcok
                    executeQueue.get(0).removeindex(i);//remove current index
                    executeQueue.get(0).setListInfo(i);//save state of process instruction (case process switches)
                    i=i-1; // fix index location
                   TimeUnit.SECONDS.sleep( 2); //default to 2 seconds for out
                   break; //will select same Queue again

                }
                else if (processor.equals("EXE")) { //exe call
                    executeQueue.get(0).setProcessState(ProcessState.Terminate);// change state

                    for (int o = executeQueue.get(0).getBaseRegister(); o < executeQueue.get(0).getLimitRegister(); o++) {
                        memoryArray[o] = 0;// process leaves main memory
                    }
                    total_memory_left=total_memory_left+ executeQueue.get(0).getMemory();
                    System.out.println(executeQueue.get(0).getName() + "The Process is done finished total runtime is " + executeQueue.get(0).getTotalTime() + " Total Memory left: " + total_memory_left);// show end process
                    executeQueue.remove(0); //remove execute Queue
                    counter++;// one process done
                    break;//loop
                }
            }




        }

    }




}
