
import java.util.*;

public class Process {
    private String name; //file name
    private ProcessState state;
    private int pid;
    private int size;
    private int totalruntime;
    private ArrayList<String >fileStorage = new ArrayList<String>();
    private int memory;
    private int io;
    private int baseRegister;
    private int limitRegister;
    private String calculate;


    Process(String inputName,int id, int total,int mem,ProcessState p,  ArrayList<String> x) //main components of process block
    {
        this.name=inputName;
        this.pid=id;
        this.totalruntime=total;
        this.memory=mem;
        this.fileStorage=x;
        this.state= p;
    }
    public void setListInfo(int x) //removes an index/word from set of instructions for specific process
    {
        fileStorage.remove(x);
    }
    public ArrayList<String> getListInfo() //returns all instructions of process
    {
        return this.fileStorage;
    }

    public void setName(String x)
    {
        this.name=x;
    }
    public String getName()
    {
        return this.name;
    }
    public void setPid(int id)
    {
        this.pid=id;
    }
    public int getPid()
    {
        return this.pid;
    }
    public void setMemory(int x)
    {
        this.memory=x;
    }
    public int getMemory()
    {
        return memory;
    }

    public void setProcessState(ProcessState x)
    {
        this.state=x;
    }
    public ProcessState getProcessState()
    {
        return this.state;
    }

    public ArrayList<String> getList()
    {
        return fileStorage;
    }
    public void removeindex (int i) //removes index/word at location for specific process instruction
    {
        fileStorage.remove(i);
    }
    public  String getindex(int i)// gets an index/word at specific process instruction
    {
        return fileStorage.get(i);
    }

    public String printPCB() //print process block
    {
        return "Process: " + this.getName() + " Pid: " + this.getPid() + " Total memory: " + this.getMemory() + " Size of Process: " + this.getTotalTime() + " Current Process State: " + this.getProcessState() ;
    }
    public void setBaseRegister(int x)
    {
        this.baseRegister=x;
    }
    public int getBaseRegister()
    {
        return baseRegister;
    }

    public void setLimitRegister(int x)
    {
        this.limitRegister=x;
    }

    public int getLimitRegister()
    {
        return limitRegister;
    }
    public void setTotalTime(int x)
    {
        this.totalruntime=x;
    }
    public int getTotalTime()
    {
        return totalruntime;
    }

}